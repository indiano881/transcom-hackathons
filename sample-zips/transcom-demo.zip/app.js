function showMessage() {
    alert('Welcome to Transcom Innovation!');
}
