function handleClick() {
    document.querySelector('.cta').textContent = 'Coming Soon!';
}
